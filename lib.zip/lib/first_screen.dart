// ignore_for_file: avoid_print, use_build_context_synchronously, unused_local_variable

import 'dart:convert';
import 'dart:core';
import 'package:flutter/material.dart';
import 'package:notes/second_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class First extends StatefulWidget {
  const First({super.key});

  @override
  State<First> createState() => _FirstState();
}

// myGridView() {
//   return GridView.builder(
//     itemCount: 3,
//     gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//         crossAxisCount: 2, crossAxisSpacing: 10),
//     itemBuilder: (context, index) {
//       return SizedBox(
//         height: MediaQuery.of(context).size.height * 0.2,
//         width: MediaQuery.of(context).size.width * 0.2,
//         child: Image.network(
//             "https://i.pinimg.com/736x/09/ee/97/09ee9790e4a873be73302693a56a9bf6.jpg"),
//       );
//     },
//   );
// }
String name = '';
String desc = "";
String fetchdata = "";

SharedPreferences prefs = SharedPreferences.getInstance() as SharedPreferences;

// testing() {
//   var map = {"name": "dushyant", "age": 18};
//   String mapString = jsonEncode(map);
//   var mapObject = jsonDecode(mapString);
//   print(mapObject["name"]);
// }

//  List todolist = [];
//  Map <String, String>user = {'title': "dushyant", 'para': "gupta"} ;
//   var result = prefs.setString('user', jsonEncode(user),);
//   ToDolist.add(user),
// Map <String, String> details = {'title': "Dushyant", 'desc': "Gupta"};
// print(details)
//     List todolist = [];
// Map<String, String>details = {'title': "title", 'para': "para"};
// String str = json.encode(details);

//  ToDolist= prefs.getString('user');
//  List<String, dynamic> ToDolist = jsonDecode(fetchdata)List<String, String>;
//    print(title);

class _FirstState extends State<First> {
  // ignore: non_constant_identifier_names
  @override
  // void initState() {
  //   super.initState();
  //   getData();
  // }

  // // ignore: non_constant_identifier_names
  // getData() async {

  //   SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  //   name = sharedPreferences.getString('title') ?? "";
  //   desc = sharedPreferences.getString('para') ?? "";
  //   fetchdata = prefs.getString('user')!;
  //   Map<String, dynamic> userMap = jsonDecode(fetchdata) as Map<String, Object>;
  //   print(title);
  //   setState(() {});
  // }

  // List<Map<String, String>> ToDoList = [];
  @override
  Widget build(BuildContext context) {
    // var _mediaQuery = MediaQuery.of(context);
   
     
      //  ToDoList = jsonDecode(fetchdata) as List<Map<String, String>>;

      // var fetchData = prefs.getString('data');
      // //  var fetchData = prefs.getString('data');
      // setState(() {
      // ToDoList = jsonDecode(fetchdata) as List<Map<String, String>>;
      // print(ToDoList);
      // });
  
    // ignore: non_constant_identifier_names
    // DecodeData() {
    //   var fetchData = prefs.getString('data');
    //   //  var fetchData = prefs.getString('data');
    //   setState(() {
    //     ToDoList = jsonDecode(fetchdata) as List<Map<String, String>>;
    //     print(ToDoList);
    //   });
    // }

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        toolbarHeight: 80,
        backgroundColor: Colors.pink,
        title: const Text(
          "Hii there",
          style: TextStyle(
              color: Colors.black, fontSize: 30, fontWeight: FontWeight.bold),
        ),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: const EdgeInsets.only(right: 16),
                  height: 40,
                  width: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.red,
                  ),
                  child: const Center(
                    child: Text("All"),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(right: 16),
                  height: 40,
                  width: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.blue,
                  ),
                  child: const Center(
                    child: Text("Favo."),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.only(right: 16),
                  height: 40,
                  width: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.green,
                  ),
                  child: const Center(
                    child: Text("Star."),
                  ),
                ),
                IconButton(
                    onPressed: () async {
                      final SharedPreferences sharedPreferences =
                          await SharedPreferences.getInstance();
                      setState(() {
                        encodedecodeData();
                      });
                      //  print(data);
                      // sharedPreferences.clear();
                      // setState(() {});
                    },
                    icon: const Icon(Icons.delete))
              ],
            ),
          ),
          Center(
            child: InkWell(
              onTap: () {
                setState(() {});
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => const Second(),
                  ),
                );
              },
              child: Container(
                height: 130,
                width: 170,
                decoration: BoxDecoration(
                    color: Colors.red[100],
                    borderRadius: BorderRadius.circular(18)),
                child: Padding(
                  padding: const EdgeInsets.only(top: 25.0),
                  child: Column(
                    children: [
                      Text(
                        fetchdata,
                        style: const TextStyle(
                            color: Colors.black,
                            fontSize: 30,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        fetchdata,
                        style: const TextStyle(
                            color: Colors.black,
                            fontSize: 15,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final SharedPreferences sharedPreferences =
              await SharedPreferences.getInstance();
          // sharedPreferences.clear();
          setState(() {});

          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => const Second(),
            ),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
 encodedecodeData() {
      List<Map<String, String>> data = [];
      Map<String, String> listMaps = {'title': "dushyant", 'para': "gupta"};
      data.add(listMaps);
      String encodeData = prefs.setString('user', jsonEncode(data)) as String;
      String getData = prefs.getString('data') as String;
      List<Map<String, String>> decodeDataList = jsonDecode(getData);
      print(decodeDataList);
 }
}
