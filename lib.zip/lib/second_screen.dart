// ignore_for_file: use_build_context_synchronously


import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'first_screen.dart';

 class Second extends StatefulWidget {
   const Second({super.key});

   @override
   State<Second> createState() => _SecondState();
 }

 String name = "";
 String desc = "";
 int value = 0;
 String title = "";
 String para = "";


 
 
class _SecondState extends State<Second> {
  @override
  void initState() {
    super.initState();
  }


  savaData() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    name = sharedPreferences.getString('title') ?? "";
    desc = sharedPreferences.getString('para') ?? "";
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.pink,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: () 
            async {
              setState(() {});
              final SharedPreferences sharedPreferences =
                  await SharedPreferences.getInstance();
              sharedPreferences.setString('title', title);
              sharedPreferences.setString('para', para);
                  
                  // todolist.add(title, para);
              // todolist.add(title , para);
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => const First(),
                ),
              );
            },
            
            icon: const Icon(
              Icons.done,
              color: Colors.white,
              size: 25,
            ),
          ),
        ],
        toolbarHeight: 80,
        title: const Text(
          "Write your Notes here...",
          style: TextStyle(color: Colors.white, fontSize: 20),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFormField(
              initialValue: title,
              onChanged: (value) {
                title = value;
              },
              decoration: const InputDecoration(
                // hintText: name.toString(),
                border: InputBorder.none,
                labelText: ("Title"),
                labelStyle: TextStyle(color: Colors.grey, fontSize: 25),
              ),
            ),
            TextFormField(
              onChanged: (value) {
                para = value;
              },
              initialValue: para,
              decoration: const InputDecoration(
                // hintText: desc.toString(),
                border: InputBorder.none,
                labelText: ("Description"),
                labelStyle: TextStyle(color: Colors.grey, fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
